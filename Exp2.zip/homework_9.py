import random as rnd
lst = []
for i in range(10):
    lst.append(rnd.randint(100, 10000))
    
print(*lst)