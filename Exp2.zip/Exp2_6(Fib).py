import functools

@functools.lru_cache()
def fibonacci(n):

    if n < 2:
        return n
    return fibonacci(n - 2) + fibonacci(n - 1)


print(fibonacci(1000))


memo = {0: 0,
        1: 1}

def fibonacci_memo(n):
    if n in memo:
        return memo[n]
    memo[n] = fibonacci_memo(n - 1) + fibonacci_memo(n - 2)
    return memo[n]


# print(fibonacci_memo(100))