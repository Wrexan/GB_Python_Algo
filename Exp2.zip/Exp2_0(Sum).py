def add(n):
    print(f'function add call with {n = }')
    if n <= 1:
        return n
    return n + add(n - 1)

print(add(5))