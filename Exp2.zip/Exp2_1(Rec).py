def recursion(a, b): # основное условие задачи
        if a > b:
            # Базовый случай
            if a == b:
                return str(a)
            
            # Шаг рекурсии / рекурсивное условие
            return str(a) + ">" + str(recursion(a - 1, b))
        else:
            
            # Базовый случай
            if a == b:
                return str(a)
            
            # Шаг рекурсии / рекурсивное условие
            return str(a) + "<" + str(recursion(a + 1, b))



print(recursion(20, 15))
print(recursion(10, 15))


